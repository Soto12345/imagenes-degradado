
package figutras;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


public class Degradado extends JFrame{
    private JPanel contentPane;
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Degradado frame = new Degradado();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public Degradado() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        setBounds(0,0,800,600);
    }
    
    public void paint (Graphics g)
    {
        super.paint(g);

        //color 
//        g.setColor(new Color (51,200,255));
        g.fillRect(1, 1, 800, 600);
        g.drawString("Tipos de lineas",50,50);
        Graphics2D lineas =(Graphics2D)g;
        g.setColor(Color.white);
        
        float guiones1[]={10,10};
        float guiones2[]={21,9,3,9};
        float guiones3[]={25,25};
        float guiones4[]={5};
        
        lineas.setStroke(new BasicStroke(2,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND,0,guiones1,0));
        lineas.drawLine(50, 80, 150, 180);
        lineas.setStroke(new BasicStroke(3,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,0,guiones2,0));
        lineas.drawLine(150, 80, 250, 180);
        lineas.setStroke(new BasicStroke(4,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND,0,guiones3,0));
        lineas.drawLine(250, 80, 350, 180);
        lineas.setStroke(new BasicStroke(5,BasicStroke.CAP_SQUARE,BasicStroke.JOIN_ROUND,0,guiones4,0));
        lineas.drawLine(350, 80, 450, 180);
        lineas.setStroke(new BasicStroke(1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,0,guiones1,0));
        lineas.drawRect(500, 80, 100, 100);
        lineas.drawOval(650,80, 100, 100);
        //imagenes
        g.setColor(Color.white);
        g.drawString("--Imagenes--",50,240);
        ImageIcon rec1=new ImageIcon(getClass().getResource("../imagenes/ps2.jpg"));
        g.drawImage(rec1.getImage(), 50, 240, this);
        ImageIcon rec2=new ImageIcon(getClass().getResource("../imagenes/360.jpg"));
        g.drawImage(rec2.getImage(), 180, 240, this);
        
        //degradado lineal y radial
        
        g.setColor(Color.white);
        g.drawString("-- degradado lineal--",50,350);
        
        Graphics2D figDegradado=(Graphics2D)g;
        
        
        GradientPaint degradado=new GradientPaint(0,0,Color.blue,20,20,Color.cyan,true);
        figDegradado.setPaint(degradado);
        figDegradado.fillRect(50,400, 150, 100);
        GradientPaint degradado2=new GradientPaint(0,0,Color.white,20,20,Color.yellow,true);
        figDegradado.setPaint(degradado2);
        figDegradado.fillRect(230,400, 100, 100);
        
        
    }
}
