/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figutras;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MultipleGradientPaint.CycleMethod;
import java.awt.RadialGradientPaint;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


public class Degradado2 extends JFrame{
    private JPanel contentPane;
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Degradado2 frame = new Degradado2();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public Degradado2() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        setBounds(0,0,800,600);
    }
    
    public void paint (Graphics g)
    {
        super.paint(g);
        
        g.setColor(Color.white);
        g.drawString("-- Degradado lineal --", 360, 350);
        
        Point2D puntoCentral=new Point2D.Float(360,360);
        float radio=15;
        
        Point2D foco=new Point2D.Float(20,25);
        Graphics2D figDegradado=(Graphics2D)g;
        float[]distribucionColor={0.0f,0.5f,1.0f};
        
        Color[] colores={Color.red,Color.white,Color.orange};
        
        RadialGradientPaint degradadoR=new RadialGradientPaint(puntoCentral,radio,foco,distribucionColor,colores,CycleMethod.REPEAT);
        
        figDegradado.setPaint(degradadoR);
        figDegradado.fillRect(360,360,150,130);
        
        //Texturizado
        g.setColor(Color.white);
        g.drawString("-- texturizado --",550,240);
        
        BufferedImage buffer=new BufferedImage(80,80,BufferedImage.TYPE_INT_RGB);
        
        Graphics2D textura=buffer.createGraphics();
        
        textura.setColor(Color.darkGray);
        textura.fillRect(0, 0, 80, 80);
        
        textura.setColor(Color.green);
        textura.fillRect(20, 20, 20, 20);
        textura.fillRect(40, 40, 20, 20);
        
        textura.setColor(Color.black);
        textura.fillRect(240, 20, 20, 20);
        textura.fillRect(20, 40, 20, 20);
        TexturePaint texturaimagen=new TexturePaint(buffer,new Rectangle(80,80));
        Graphics2D g2d=(Graphics2D) g;
        g2d.setPaint(texturaimagen);
        g2d.fillOval(550, 250, 200, 200);
        
        try{
            BufferedImage bufferI=ImageIO.read(this.getClass().getResource("imagenes/360.jpg"));
            TexturePaint texturaLadrillo =new TexturePaint(bufferI,new Rectangle(50,50));
            Graphics2D ladrillo=(Graphics2D)g;
            ladrillo.setPaint(texturaLadrillo);
            ladrillo.fillOval(600, 460, 120, 120);
        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}